# rust-analyzer

Provides support for rust-analyzer: novel LSP server for the Rust programming language.

See https://rust-analyzer.github.io/ for more information.
